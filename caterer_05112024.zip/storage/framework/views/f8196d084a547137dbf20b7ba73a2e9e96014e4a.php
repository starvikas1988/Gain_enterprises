
<div class="table-responsive">
  <!--begin::Table-->
  <table class="table table-centered table-nowrap mb-0">    
      <thead class="table-light">
        <th>Sl No.</th>
        <th>Customer</th>
        <th>Opening</th>
        <th>Credit</th>
        <th>Debit</th>
        <th>Closing</th>
        <th>Message</th>
        <th>Date</th>
    </thead>
    <tbody> 
      <?php $serial = $serial[0]; ?>
      <?php if($result->isNotEmpty()): ?>
        <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>        
        <tr>
          <td><?php echo e($serial+$key); ?></td>
          <td><?php echo e($row->customer->name); ?><br><?php echo e($row->customer->user_code); ?></td> 
          <td><?php echo e($row->opening); ?></td> 
          <td><?php echo e($row->credit); ?></td> 
          <td><?php echo e($row->debit); ?></td> 
          <td><?php echo e($row->closing); ?></td> 
          <td><?php echo e($row->message); ?></td> 
          <td><?php echo e($row->created_at); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php else: ?>
        <tr>  
          <td colspan="10">No data found..</td>
        </tr>
      <?php endif; ?>
      
    </tbody>
    <!--end::Table body-->
  </table>
  <!--end::Table-->
  <div class="clearfix"><br/></div>
  <div align="left"><?php echo $result; ?></div>
</div><?php /**PATH /home/u220041557/domains/gainenterprises.in/public_html/caterer/resources/views/admin/transaction/table.blade.php ENDPATH**/ ?>