<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

use App\Models\Driver;
use App\Models\DriverKyc;
use Auth;
use DB;
use Hash;

class DriverController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth:admin');
        $this->middleware(function ($request, $next) {
            if(Auth::user()->can(request()->segment(2))){
                return $next($request);
            }
            abort(403);
        });
    }

    /**
     * show dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if(!$request->ajax())
            return view('admin.driver.header',['title'=>'Driver list']);
        else
        {
            //dd($request->all());
            $limit = 10;
            $serial[] = (request()->input('page')==0)?1:(($limit*(request()->input('page')-1))+1);
            $query = Driver::where('id','>','0');
            // Search Start
            if($request->input('skey')!=''){
                echo 'YES';
                $query = $query->where('name','LIKE','%'.$request->input('skey').'%');
                $query = $query->OrWhere('mobile','LIKE','%'.$request->input('skey').'%');
                $query = $query->OrWhere('email','LIKE','%'.$request->input('skey').'%');
            }
            if($request->input('sstat')!='')
                $query = $query->where('status','=', $request->input('sstat'));

            if($request->input('sdate')!='')
                $query = $query->whereDate('created_at','=', $request->input('sdate'));
            // Search End
            $count = $query->count();
            $result = $query->orderBy('id','DESC')->paginate($limit);
            return view('admin.driver.table',['serial'=>$serial,'count'=>$count,'result'=>$result]);
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.driver.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $sValidationRules = [
            'name' => 'required',
            'address' => 'required',
            'email' => 'required|email|unique:drivers',
            'mobile' =>'required|digits:10,|unique:drivers',
            'password' => 'required|required_with:password_again|same:password_again',
        ];
        $validator = Validator::make($request->all(), $sValidationRules);
        if ($validator->fails()) // on validator found any error 
        {
            return redirect(route('admin.driver.create'))->withErrors($validator)->withInput();
        }
        $franchisee = New Driver;
        $franchisee->name = $request->name;
        $franchisee->email = $request->email;
        $franchisee->mobile = $request->mobile;
        $franchisee->charge = $request->charge;
        $franchisee->address = $request->address;
        $franchisee->shop_name = $request->shopname;
        $franchisee->creditlimit = $request->creditlimit;
        $franchisee->pincode = $request->pincode;
        if($request->hasFile('userfile')){
            $image = rand().time().'.'.$request->userfile->extension();
            $request->userfile->move(public_path('uploads/driver'), $image);
            $franchisee->profileimg = 'public/uploads/driver/'.$image;
        }
        $franchisee->password = bcrypt($request->password);
        $franchisee->save();        
        return redirect(route('admin.drivers'))->withSuccess('Added successfully');
    }

    public function edit(Request $request)
    {
        $driver = Driver::Where('id','=',$request->id)->get();
        return view('admin.driver.edit',['driver'=>$driver]);
    }
    
    public function update(Request $request)
    {
        $sValidationRules = [
            'name' => 'required',
            'address' => 'required',
            'email' => 'required|email|unique:drivers,email,'.$request->id,
            'mobile' => 'required|digits:10,|unique:drivers,mobile,'.$request->id,
        ];
        $validator = Validator::make($request->all(), $sValidationRules);
        if ($validator->fails()) // on validator found any error 
        {
            return redirect(route('admin.driver.edit',['id'=>$request->id]))->withErrors($validator)->withInput();
        }
        $franchisee = Driver::find($request->id);
        $franchisee->name = $request->name;
        $franchisee->shop_name = $request->shopname;
        $franchisee->pincode = $request->pincode;
        $franchisee->email = $request->email;
        $franchisee->mobile = $request->mobile;
        $franchisee->address = $request->address;
        $franchisee->charge = $request->charge;
        $franchisee->creditlimit = $request->creditlimit;
		$franchisee->status = $request->status;
        if($request->hasFile('userfile')){
            $image = rand().time().'.'.$request->userfile->extension();
            $request->userfile->move(public_path('uploads/driver'), $image);
            $franchisee->profileimg = 'public/uploads/driver/'.$image;
        }
        $franchisee->save();
        return redirect(route('admin.drivers'))->withSuccess('Update successfully');
    }
    
    public function destroy(Request $request)
    {
        Driver::where('id', '=', $request->id)->delete();
        return redirect(route('admin.drivers'))->withSuccess('Deleted successfully');
    }
    
    public function kyc(Request $request)
    {
        $driverKyc = Driverkyc::Where('driver_id','=',$request->id)->get();
        if($driverKyc->isNotEmpty()){
        	return view('admin.driver.kyc',['user'=>$driverKyc]);
		} else 
			return redirect(route('admin.driver'))->withErrors('No kyc found');
    }
	
    public function kycupdate(Request $request)
    {
		$userdt = DriverKyc::Where('driver_id','=',$request->id)->get();
        $user = DriverKyc::find($userdt[0]->id);
		$user->aadhar_no = $request->aadhar_no;
		$user->cab_registration_no = $request->cab_registration_no; 
		$user->driving_licence_no = $request->driving_licence_no;
		$user->status = $request->status;
        $user->save();
				
		$driver = Driver::find($request->id);
		$driver->kyc_status = $request->status;
		$driver->save();
		
        return redirect(route('admin.driver.kyc',['id'=>$userdt[0]->driver_id]))->withSuccess('Update successfully');
    }

}
