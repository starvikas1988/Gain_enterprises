<?php

use Illuminate\Support\Facades\Route;


Route::post('v1/webconfig', [App\Http\Controllers\Api\HomeController::class, 'webconfig']);

Route::post('v1/customer/login', [App\Http\Controllers\Api\CustomerAuthController::class, 'customlogin']);
Route::post('v1/customer/register', [App\Http\Controllers\Api\CustomerAuthController::class, 'customregistration']);
Route::post('v1/customer/mobilevalidate', [App\Http\Controllers\Api\CustomerAuthController::class, 'mobilevalidate']);

Route::prefix('v1/')->group(function () {	
	Route::middleware(['auth:sanctum', 'type.customer'])->group(function () {
	    
		Route::post('customer/profile', [App\Http\Controllers\Api\CustomerController::class, 'profile']);
		Route::post('customer/updateprofile', [App\Http\Controllers\Api\CustomerController::class, 'updateprofile']);
		Route::post('customer/updateprofileimg', [App\Http\Controllers\Api\CustomerController::class, 'updateprofileimg']);
		Route::post('customer/logout', [App\Http\Controllers\Api\CustomerController::class, 'logout']);
		
		Route::post('customer/getAllCategories', [App\Http\Controllers\Api\CustomerController::class, 'getAllCategories']);
		Route::post('customer/getAllRestaurant', [App\Http\Controllers\Api\CustomerController::class, 'getAllRestaurant']);
		Route::post('customer/getAllProductByRestaurantIdWithFilter', [App\Http\Controllers\Api\CustomerController::class, 'getAllProductByRestaurantIdWithFilter']);
		Route::post('customer/getAllProductByCategoryId', [App\Http\Controllers\Api\CustomerController::class, 'getAllProductByCategoryId']);
		
		
		Route::post('customer/report/transaction', [App\Http\Controllers\Api\ReportController::class, 'transaction']);	
		Route::post('customer/updatedevicetoken', [App\Http\Controllers\Api\CustomerController::class, 'updatedevicetoken']);
		Route::post('customer/allnotification', [App\Http\Controllers\Api\CustomerController::class, 'notificationlist']);
	});	
});
