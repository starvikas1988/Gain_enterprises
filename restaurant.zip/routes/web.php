<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
//Clear Cache facade value:
Route::get('/clearcache', function() {
    $exitCode = Artisan::call('cache:clear');
    $exitCode = Artisan::call('optimize');
    $exitCode = Artisan::call('route:cache');
    $exitCode = Artisan::call('config:cache');
    $exitCode = Artisan::call('route:clear');
    $exitCode = Artisan::call('view:clear');
    return '<h1>Cache facade value cleared</h1>';
});

Route::get('/', [App\Http\Controllers\HomeController::class, 'index'])->name('index');
Route::get('/index', [App\Http\Controllers\HomeController::class, 'index'])->name('index');

/* ajax json response */
Route::get('/customersearch', [App\Http\Controllers\CommonController::class, 'selectCustomerSearch'])->name('customersearch');
Route::post('/getbalance', [App\Http\Controllers\CommonController::class, 'get_balance'])->name('balance'); 

Auth::routes();
Route::prefix('admin')->group(function() {
    Route::get('/', [App\Http\Controllers\Auth\AdminLoginController::class, 'showLoginForm'])->name('admin.login');
    Route::get('/login', [App\Http\Controllers\Auth\AdminLoginController::class, 'showLoginForm'])->name('admin.login');
    Route::post('/login', [App\Http\Controllers\Auth\AdminLoginController::class, 'login'])->name('admin.login.submit');
    Route::get('logout/', [App\Http\Controllers\Auth\AdminLoginController::class, 'logout'])->name('admin.logout');

    Route::group(['middleware' => ['auth:admin']], function() {
        Route::get('/dashboard', [App\Http\Controllers\Admin\HomeController::class, 'index'])->name('admin.dashboard');
        Route::get('/myprofile', [App\Http\Controllers\Admin\HomeController::class, 'myprofile'])->name('admin.myprofile');
        Route::post('/updateprofile', [App\Http\Controllers\Admin\HomeController::class, 'updateprofile'])->name('admin.updateprofile');
        Route::get('/changepassword', [App\Http\Controllers\Admin\HomeController::class, 'changepassword'])->name('admin.changepassword');
        Route::post('/passwordchange', [App\Http\Controllers\Admin\HomeController::class, 'passwordchange'])->name('admin.passwordchange');

        Route::get('/users', [App\Http\Controllers\Admin\UserController::class, 'index'])->name('admin.users');
        Route::get('/add-user', [App\Http\Controllers\Admin\UserController::class, 'create'])->name('admin.user.create');
        Route::get('/show-user/{id}', [App\Http\Controllers\Admin\UserController::class, 'show'])->name('admin.user.show');
        Route::post('/add-user', [App\Http\Controllers\Admin\UserController::class, 'store'])->name('admin.user.store');
        Route::get('/edit-user/{id}', [App\Http\Controllers\Admin\UserController::class, 'edit'])->name('admin.user.edit');
        Route::post('/edit-user/{id}', [App\Http\Controllers\Admin\UserController::class, 'update'])->name('admin.user.update');        
        Route::get('/delete-user/{id}', [App\Http\Controllers\Admin\UserController::class, 'destroy'])->name('admin.user.delete'); 
			        
		Route::get('/drivers', [App\Http\Controllers\Admin\DriverController::class, 'index'])->name('admin.driver');
        Route::get('/add-driver', [App\Http\Controllers\Admin\DriverController::class, 'create'])->name('admin.driver.create');
        Route::get('/show-driver/{id}', [App\Http\Controllers\Admin\DriverController::class, 'show'])->name('admin.driver.show');
        Route::post('/add-driver', [App\Http\Controllers\Admin\DriverController::class, 'store'])->name('admin.driver.store');
        Route::get('/edit-driver/{id}', [App\Http\Controllers\Admin\DriverController::class, 'edit'])->name('admin.driver.edit');
        Route::post('/edit-driver/{id}', [App\Http\Controllers\Admin\DriverController::class, 'update'])->name('admin.driver.update');        
        Route::get('/delete-driver/{id}', [App\Http\Controllers\Admin\DriverController::class, 'destroy'])->name('admin.driver.delete'); 
		
		Route::get('/driver-kyc/{id}', [App\Http\Controllers\Admin\DriverController::class, 'kyc'])->name('admin.driver.kyc');
		Route::post('/driver-kyc/{id}', [App\Http\Controllers\Admin\DriverController::class, 'kycupdate'])->name('admin.driver.kyc.update');
        
		Route::get('/admins', [App\Http\Controllers\Admin\AdminController::class, 'index'])->name('admin.admins');
        Route::get('/add-admin', [App\Http\Controllers\Admin\AdminController::class, 'create'])->name('admin.admin.create');
        Route::post('/add-admin', [App\Http\Controllers\Admin\AdminController::class, 'store'])->name('admin.admin.store');
        Route::get('/edit-admin/{id}', [App\Http\Controllers\Admin\AdminController::class, 'edit'])->name('admin.admin.edit');
        Route::post('/edit-admin/{id}', [App\Http\Controllers\Admin\AdminController::class, 'update'])->name('admin.admin.update');        
        Route::get('/delete-admin/{id}', [App\Http\Controllers\Admin\AdminController::class, 'destroy'])->name('admin.admin.delete');
		
        Route::get('/roles', [App\Http\Controllers\Admin\RoleController::class, 'index'])->name('admin.roles');
        Route::get('/add-role', [App\Http\Controllers\Admin\RoleController::class, 'create'])->name('admin.role.create');
        Route::post('/add-role', [App\Http\Controllers\Admin\RoleController::class, 'store'])->name('admin.role.store');
        Route::get('/edit-role/{id}', [App\Http\Controllers\Admin\RoleController::class, 'edit'])->name('admin.role.edit');
        Route::post('/edit-role/{id}', [App\Http\Controllers\Admin\RoleController::class, 'update'])->name('admin.role.update');
        Route::get('/delete-role/{id}', [App\Http\Controllers\Admin\RoleController::class, 'destroy'])->name('admin.role.delete');
		Route::get('/permissionlist/{id}', [App\Http\Controllers\Admin\RoleController::class, 'permissionlist'])->name('admin.role.permissionlist');
        Route::post('/update-permission/{id}', [App\Http\Controllers\Admin\RoleController::class, 'updatepermission'])->name('admin.role.updatepermission');

        Route::get('/permissions', [App\Http\Controllers\Admin\PermissionController::class, 'index'])->name('admin.permissions');
        Route::get('/add-permission', [App\Http\Controllers\Admin\PermissionController::class, 'create'])->name('admin.role.permission');
        Route::post('/add-permission', [App\Http\Controllers\Admin\PermissionController::class, 'store'])->name('admin.permission.store');
        Route::get('/edit-permission/{id}', [App\Http\Controllers\Admin\PermissionController::class, 'edit'])->name('admin.permission.edit');
        Route::post('/edit-permission/{id}', [App\Http\Controllers\Admin\PermissionController::class, 'update'])->name('admin.permission.update');
		
        Route::get('/transactions', [App\Http\Controllers\Admin\TransactionController::class, 'index'])->name('admin.transactions');
		Route::get('/customersettlements', [App\Http\Controllers\Admin\CustomersettlementController::class, 'index'])->name('admin.customersettlements');
        Route::get('/add-customersettlement', [App\Http\Controllers\Admin\CustomersettlementController::class, 'create'])->name('admin.customersettlement.create');
        Route::post('/add-customersettlement', [App\Http\Controllers\Admin\CustomersettlementController::class, 'store'])->name('admin.customersettlement.store');
				
        Route::get('/websiteconfigs', [App\Http\Controllers\Admin\WebsiteconfigController::class, 'index'])->name('admin.websiteconfigs');
        Route::post('/edit-websiteconfig', [App\Http\Controllers\Admin\WebsiteconfigController::class, 'update'])->name('admin.websiteconfig.update');
		
        Route::get('/admincharges', [App\Http\Controllers\Admin\AdminchargeController::class, 'index'])->name('admin.admincharges');
		Route::get('/tdscharges', [App\Http\Controllers\Admin\TdschargeController::class, 'index'])->name('admin.tdscharges');
				
    });
    
});