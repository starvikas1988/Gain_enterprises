<?php
return [
    'website'=>'Blank Admin',
	'websiteLink'=>'',
	'logo'=>'',
	'email'=>'',
	'mobile'=>'',
	'address'=>'',
	'docspath'=>'',
];