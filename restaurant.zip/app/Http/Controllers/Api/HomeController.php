<?php
namespace App\Http\Controllers\API;
 
use Validator;
use Illuminate\Http\Request;

use Symfony\Component\HttpFoundation\Response;
use App\Http\Controllers\Controller;
use Laravel\Sanctum\HasApiTokens; 

use App\Models\User;
use App\Models\Websiteconfig;
use Route;
use DB;

class HomeController extends Controller
{
    public $token = true;
	public function __construct()
    {	
		
    }	
	
	public function webconfig()
	{
		$website = Websiteconfig::first(); 
		$arraystore = array(
			'appVersion'=> $website->app_version,
			'maintainanceMode'=> $website->maintainance_mode,
		);
		return response()->json(['success' => true,'message' => 'data found', 'data'=>$arraystore], 200);
	}	
}