<?php
namespace App\Http\Controllers\API;

use Validator;
use App\Models\Transaction;
use App\Models\User;
use App\Models\Category;
use App\Models\Product;
use App\Models\Restaurant;
use App\Models\RestaurantCategory;


use App\Models\Notification;
use App\Models\Websiteconfig;
use Illuminate\Support\Str;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

use Symfony\Component\HttpFoundation\Response;
use App\Http\Controllers\Controller;
use Laravel\Sanctum\HasApiTokens; 
use Route;
use Image;
use File;
use Hash;
use DB;

class CustomerController extends Controller
{
    public $token = true;
	public function __construct()
    {	
		if(Route::middleware('auth:sanctum')){
			return response()->json(['success' => false,'errorcode'=>'05','message' => 'Unauthorized','data'=>array()], 401);
		}		
    }
	
	public function profile()  
	{
		$customer = User::where('id', auth()->user()->id)->first(['id', 'name', 'mobile', 'gender', 'dob', 'email', 'balance', 'profileimg', 'created_at']);
		return response()->json(['success' => true,'errorcode'=>'00','message' => 'data found', 'data'=>$customer], 200);
	}
	
	public function getAllRestaurant(Request $request)
	{
	    $restaurant = Restaurant::Where('status','A')->orderBy('id', 'DESC')->get(['id', 'name', 'image', 'rating']); 
		if($restaurant->isNotEmpty())
			return response()->json(['success' => true,'errorcode'=>'00','message' => 'data found', 'data'=>$restaurant], 200);
		else
			return response()->json(['success' => false,'errorcode'=>'04', 'message'=>'No data found!', 'data'=>array()], 200);
	}
	
	
	public function getAllProductByRestaurantIdWithFilter(Request $request)
	{
	    $validator = Validator::make($request->all(), 
		[
            'restaurantId' => 'required',
		]);
		if ($validator->fails())
			return response()->json(['success' => false,'errorcode'=>'04', 'message'=>$validator->errors()->first(), 'data'=>array()], 200);			
		else 
		{
            $query = Restaurant::with('categories.category.products')->where('status', 'A');
            
            if ($request->categoryId) {
                $query->whereHas('categories', function ($query) use ($request) {
                    $query->where('category_id', $request->categoryId);
                });
            }
            
            $restaurant = $query->where('id', $request->restaurantId)->first();
        
            if (!$restaurant) {
                return response()->json(['success' => false,'errorcode'=>'04', 'message'=>'No data found!', 'data'=>array()], 200);
            }
            
            $categories = $restaurant->categories->sortByDesc('category_id')->filter(function ($restaurantCategory) use ($request) {
                return !$request->categoryId || $restaurantCategory->category_id == $request->categoryId;
            });
        
            $formattedRestaurant = [
                'id' => $restaurant->id,
                'name' => $restaurant->name,
                'image' => $restaurant->image,
                'rating' => $restaurant->rating,
                'categories' => $categories->map(function ($restaurantCategory) {
                    return [
                        'category_id' => $restaurantCategory->category->id,
                        'category_name' => $restaurantCategory->category->name,
                        'icon' => $restaurantCategory->category->icon,
                    ];
                })->values(),
                'products' => $categories->flatMap(function ($restaurantCategory) {
                    return $restaurantCategory->category->products->map(function ($product) {
                        return [
                            'product_id' => $product->id,
                            'product_name' => $product->name,
                            'product_image' => $product->image,
                            'price' => $product->price,
                            'description' => $product->description,
                        ];
                    });
                }),
            ];

    		if($formattedRestaurant)
    			return response()->json(['success' => true,'errorcode'=>'00','message' => 'data found', 'data'=>$formattedRestaurant], 200);
    		else
    			return response()->json(['success' => false,'errorcode'=>'04', 'message'=>'No Product found!', 'data'=>array()], 200);
		}
	}
	
	public function getAllCategories()
	{
	    $category = Category::Where('status','A')->orderBy('id', 'DESC')->get(['id', 'name', 'icon']); 
		if($category->isNotEmpty())
			return response()->json(['success' => true,'errorcode'=>'00','message' => 'data found', 'data'=>$category], 200);
		else
			return response()->json(['success' => false,'errorcode'=>'04', 'message'=>'No data found!', 'data'=>array()], 200);
	}
	
	public function getAllProductByCategoryId(Request $request)
	{
		$validator = Validator::make($request->all(), 
		[
            'categoryId' => 'required',
		]);
		if ($validator->fails()) {
			return response()->json(['success' => false,'errorcode'=>'04', 'message'=>$validator->errors()->first(), 'data'=>array()], 200);			
		} else {
			$product = Product::Where('status','A')->where('category_id', $request->categoryId)->orderBy('id', 'DESC')->get(['id', 'name', 'image', 'description', 'price']); 
    		if($product->isNotEmpty())
    			return response()->json(['success' => true,'errorcode'=>'00','message' => 'data found', 'data'=>$product], 200);
    		else
    			return response()->json(['success' => false,'errorcode'=>'04', 'message'=>'No Product found!', 'data'=>array()], 200);
		}
	}
	
	public function notificationlist()
	{
		$notification = Notification::Where('notification_type','Customer')->OrWhereIn('user_id', [auth()->user()->id])->get(); 
		if($notification->isNotEmpty())
			return response()->json(['success' => true,'errorcode'=>'00','message' => 'data found', 'data'=>$notification], 200);
		else
			return response()->json(['success' => false,'errorcode'=>'04', 'message'=>'No data found!', 'data'=>array()], 200);	
	}
	
	public function updateprofileimg(Request $request)
	{
		$input = $request->all();
		$userid = auth()->user()->id;
		$validator = Validator::make($request->all(), 
		[
			'images.*' => 'required|image|mimes:jpg,jpeg,png|max:2048',
		]);
		if ($validator->fails()) {
			return response()->json(['success' => false,'errorcode'=>'04', 'message'=>$validator->errors()->first(), 'data'=>array()], 200);			
		} else {			
			if ($request->hasFile('image')) 
			{
				$imageName = time().'.'.$request->image->extension();      
				$path = 'public/profileimg/'.$imageName;
				$request->image->move(public_path('profileimg'), $imageName);

				$address = User::find($userid);
				$address->profileimg = $path;
				$address->save();
				return response()->json(['success' => true,'errorcode'=>'00', 'message'=>"Updated successfully.", 'data'=>array()], 200);	
			}
			else {
				return response()->json(['success' => false,'errorcode'=>'02', 'message'=>"Invalid image file", 'data'=>array()], 200);	
			}
		}
	}
	
	public function updateprofile(Request $request)
	{
		$input = $request->all();
		$userid = auth()->user()->id;
		$validator = Validator::make($request->all(), 
		[
            'gender' => 'required',
			'name' => 'required',
			'dob' => 'required',
			'email' => 'required',
		]);
		if ($validator->fails()) {
			return response()->json(['success' => false,'errorcode'=>'04', 'message'=>$validator->errors()->first(), 'data'=>array()], 200);			
		} else {
			$address = User::find($userid);
			$address->name = $request->name;
			$address->gender = $request->gender;
			$address->email = strtolower($request->email);
			$address->dob = date('Y-m-d', strtotime($request->dob));
			$address->save();
			return response()->json(['success' => true,'errorcode'=>'00', 'message'=>"Updated successfully.", 'data'=>array()], 200);
		}
	}	
	
	public function mainwallet()
	{
		$transaction = Transaction::Where('user_id',auth()->user()->id)->OrderBy('id','DESC')->get(); 
		if($transaction->isNotEmpty())
			return response()->json(['success' => true,'errorcode'=>'00','message' => 'data found', 'data'=>$transaction], 200);
		else
			return response()->json(['success' => false,'errorcode'=>'04', 'message'=>'No data found!', 'data'=>array()], 200);	
	}
	
	public function logout()
	{
        auth()->user()->currentAccessToken()->delete();
        return response()->json(['success' => true,'errorcode'=>'00', 'message'=>'Logout successfully.', 'data'=>array()], 200);
    }
	
	public function updatedevicetoken(Request $request)
	{
		User::Where('id',auth()->user()->id)->update(['device_id'=>$request->deviceid]); 
		return response()->json(['success' => true,'message' => 'updated successfully', 'data'=>array()], 200);
	}
	
	public static function slugify($text, string $divider = '-')
	{
	  	$text = preg_replace('~[^\pL\d]+~u', $divider, $text);
	  	$text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);
	  	$text = preg_replace('~[^-\w]+~', '', $text);
	  	$text = trim($text, $divider);
	  	$text = preg_replace('~-+~', $divider, $text);
	  	$text = strtolower($text);
	  	if (empty($text)) {	
			return 'n-a';
	  	}
	  	return $text;
	}	
}