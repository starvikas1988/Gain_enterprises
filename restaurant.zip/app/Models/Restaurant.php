<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory; 
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Restaurant extends Model
{
    use HasFactory, SoftDeletes;
    protected $fillable = [];
    
    public function getImageAttribute($value)
    {
        return env('ASSET_URL') . $value;
    }
    
    public function categories()
    {
        return $this->hasMany(RestaurantCategory::class);
    }
    
}